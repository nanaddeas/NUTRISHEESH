<?php

namespace App\Http\Controllers;

use App\Models\MealPlanningg;
use Illuminate\Http\Request;

class MealPlanninggController extends Controller
{
    public function index(Request $request){

        if($request->has('search')){
            $data = MealPlanningg::where('menu','LIKE', '%'.$request->search.'%')->paginate(3);
        }else{
            $data = MealPlanningg::paginate(3);
        }

        return view('mealplanningg', compact('data'));
    }

    public function tambahdataresep(){
        return view('tambahdata');
    }

    public function insertdataresep(Request $request){
        //dd($request->all());
        $data = MealPlanningg::create($request->all());
        if($request->hasFile('foto')){
            $request->file('foto')->move('fotomakanan/', $request->file('foto')->getClientOriginalName());
            $data->foto = $request->file('foto')->getClientOriginalName();
            $data->save();
        }
        return redirect()->route('mealPlanningg')->with('success','Resep Berhasil Di Tambahkan');
    }

    public function tampilkandata($id){
        $data = MealPlanningg::find($id);
        //dd($data);

        return view('tampildata', compact('data'));
    }

    public function updatedata(Request $request, $id){
        $data = MealPlanningg::find($id);
        $data->update($request->all());
        return redirect()->route('mealPlanningg')->with('success','Resep Berhasil Di Update');

    }

    public function delete($id){
        $data = MealPlanningg::find($id);
        $data->delete();
        return redirect()->route('mealPlanningg')->with('success','Resep Berhasil Di Hapus');

    }
}
