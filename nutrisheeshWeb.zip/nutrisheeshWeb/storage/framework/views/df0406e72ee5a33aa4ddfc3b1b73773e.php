<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Web Nutrisheesh</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  </head>
  <body>
    <h1 class="text-center mb-5">Nutrisheesh</h1>

    <div class="container">
        <button type="button" class="btn btn-primary"
        style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">
        Tambahkan resep +
        </button>
        <div class="row">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Menu</th>
                    <th scope="col">Bahan</th>
                    <th scope="col">Resep</th>
                    <th scope="col">Done / Not Yet</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Telur Orak Arik</td>
                    <td>1 bungkus Mi<br>
                        2 butir telur <br>
                        1 buah wortel besar <br>
                        Kubis <br>
                        Wortel <br>
                        Air secukupnya <br>
                        Minyak goreng <br>
                        Bumbu <br>
                        Bawang putih <br>
                        Garam <br>
                        Kemiri <br>
                        Merica <br>
                        tomat <br>
                        2 butir telur <br>
                        daun bawang <br>
                        seledri <br>
                        bawang merah <br></td>
                    <td>1. Persiapkan bahan - bahan <br>
                        2. Rebus mie didalam air mendidih sebentar, tiriskan <br>
                        3. Kemudian, tambahkan kecap manis, aduk -aduk agar Mie berwarna kecoklatan dan meresap <br>
                        4. Uleg bawang putih, kemiri, merica dan garam <br>
                        5. Membuat Orak-Arik telur, kemudian sisihkan <br>
                        6. Lanjutkan menumis bumbu uleg (api kecil saja biar tidak cepat gosong) <br>
                        7. Tambahkan air secukupnya. Dan masukkan bahan tambahan seperti sayuran, daun bawang dan wortel <br>
                        8. Tunggu sampai agak empuk, lalu masukkan mie nya, dan aduk pelan-pelan, gunakan Api Kecil <br>
                        9. Sajikan selagi masih hangat <br>
                    </td>
                    <td>
                        <button type="button" class="btn btn-outline-primary">Done</button>
                        <button type="button" class="btn btn-outline-secondary">Not Yet</button>
                    </td>
                  </tr>
                </tbody>
              </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-fbbOQedDUMZZ5KreZpsbe1LCZPVmfTnH7ois6mU1QK+m14rQ1l2bGBq41eYeM/fS" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\laragon\www\nutrisheeshWeb\resources\views/mealplanning.blade.php ENDPATH**/ ?>