<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MealPlanninggController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/mealPlanningg', [MealPlanninggController::class, 'index'])->name('mealPlanningg');

Route::get('/tambahdataresep', [MealPlanninggController::class,'tambahdataresep'])->name('tambahdataresep');
Route::post('/insertdataresep', [MealPlanninggController::class,'insertdataresep'])->name('insertdataresep');

Route::get('/tampilkandata/{id}', [MealPlanninggController::class,'tampilkandata'])->name('tampilkandata');
Route::post('/updatedata/{id}', [MealPlanninggController::class,'updatedata'])->name('updatedata');

Route::get('/delete/{id}', [MealPlanninggController::class,'delete'])->name('delete');
